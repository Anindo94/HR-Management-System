<?php include 'code.php';
$cxn = mysqli_connect('localhost','nineleaps_user','nineleaps','nineleapsdb') or die("Cannot connect to Database, Please Try Later");

?>

<html>
<head>
<title>NineLeaps Demo App</title>
<link rel="stylesheet" type="text/css" href="mystyle.css">
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
</head>
<body>
<header>
<h2 class="nineleaps">NineLeaps HR Portal</h2>
</header>
<ul id="header">
  <li><a href="#home">Home |</a></li>
  <li id="employees1"><a href="table_view.php">View Employee Table</a></li>
</ul>
<h3 id="header3">&nbsp&nbsp<?php  echo $_GET['name']."&nbsp<small>[Employee]</small>" ?></h3>
<strong id="header4">Details:</strong>
<div class="box2">
<form id="form1">
Name &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp: <?php  echo "<strong>". $_GET['name']."</strong>"; ?> <br><br>
Designation &nbsp&nbsp&nbsp: <?php  echo "<strong>" . $_GET['designation']."</strong>"; ?><br><br>
Employee ID &nbsp&nbsp: <?php  echo "<strong>" . $_GET['emp_id']."</strong>"; ?><br><br>
Manager &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp: <?php  echo "<strong>". $_GET['manager']."<strong>"; ?> <br><br>
</form>
</div>
</body>
</html>