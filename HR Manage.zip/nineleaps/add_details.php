
<?php include 'code.php'; ?>

<html>
</head>
<title>NineLeaps Demo App</title>
<link rel="stylesheet" type="text/css" href="mystyle.css">
</head>
<body>
<header>
<h2 class="nineleaps">NineLeaps HR Portal</h2>
</header>
<ul id="header">
  <li><a href="#home">Home |</a></li>
  <li id="employees1"><a href="table_view.php">View Employee Table</a></li>
</ul>
<br><br>
<div class="box">
<form method="get">
  Name:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <input type="text" name="Name" size="35"><br><br>
  Designation:&nbsp <select name="Designation" id="desig" style="width: 230px;">
  	<option selected="selected" disabled="disabled">select</option>
  <option value="CEO">Ceo</option>
  <option value="Accounts Manager">accounts manager</option>
  <option value="COO">coo</option>
  <option value="Business Analysts">business analysts</option>
  <option value="Scrum Master">scrum master</option>
  <option value="Head(Quality)">head(quality)</option>
  <option value="Tester">tester</option>
  <option value="Mobile Tester">mobile tester</option>
  <option value="Head(Development)">head(development)</option>
  <option value="Developer">developer</option>
  <option value="VP Sales">vp sales</option>
  <option value="Manager Sales">manager sales</option>
  <option value="VP Marketing">vp marketing</option>
  <option value="Manager Marketing">manager marketing</option>
  <option value="Head (HR)">head(hr)</option>
  <option value="Recruitment Manager">recruitment manager</option>
  <option value="L & D Manager">l & d manager</option>
  <option value="Facilities">facilities</option>
  <option value="Head(Finance)">head(finance)</option>
  <option value="CTO">cto</option>
  <option value="Solution Architecture">solution architecture</option>
  <option value="Quality Manager">quality manager</option>
</select><br><br>
  Employee ID:&nbsp <input type="text" name="eid" size="35"><br><br>

  Manager:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <input type="text" name="Manager" size="35"><br><br>
  <input type="submit" name="submit_details" value="Submit">
  <h5 id="box1">All fields are mandatory.</h5>
 <?php echo $added ?>
</form>


</div>
</body>
</html>
