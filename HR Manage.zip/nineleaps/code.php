<?php 
$error='';



if(isset($_GET['submit'])){
	$name=$_GET['Name'];
$desig=$_GET['Designation'];
$manager=$_GET['Manager'];


	if(empty($name)||empty($desig)||empty($manager))
	{
	$error='Please fill out all the details';
	}
	else
	{
	echo "Login succesful";
	}
}

$error1='';
$error_wr_cred="";


if(isset($_GET['login1'])){
	

	$name1=$_GET['userid'];
	$pass=$_GET['psw'];

	if(empty($name1)||empty($pass))
	{
	$error1='Please fill out all the details';
	}
	else
	{



$cxn = mysqli_connect('localhost','nineleaps_user','nineleaps','nineleapsdb') or die("Cannot connect to Database, Please Try Later");
$query = mysqli_query($cxn,"SELECT * FROM hr WHERE username='$name1' and password='$pass'");
$row = mysqli_num_rows($query);
if($row==1)
{
header("location: add_details.php");
}
else
{
$error_wr_cred="Please enter the correct username and password";
}
	}
}
$added='';
if(isset($_GET['submit_details']))
{
$emp_name=$_GET['Name'];
$emp_designation=$_GET['Designation'];
$emp_manager=$_GET['Manager'];
$emp_id=$_GET['eid'];

$cxn = mysqli_connect('localhost','nineleaps_user','nineleaps','nineleapsdb') or die("Cannot connect to Database, Please Try Later");
$a="INSERT INTO edetails(name,designation,manager,eid) VALUES('$emp_name','$emp_designation','$emp_manager','$emp_id')";
$query = mysqli_query($cxn,$a);
if ($query) {
	$added="Data Added";
}
}

$cxn = mysqli_connect('localhost','nineleaps_user','nineleaps','nineleapsdb') or die("Cannot connect to Database, Please Try Later");
$query=mysqli_query($cxn,"SELECT * FROM edetails ORDER BY id ASC");
$length=mysqli_num_rows($query);
$name='';


?>
