<?php include 'code.php'; ?>
<html>
<head>
<title>NineLeaps Demo App</title>
<link rel="stylesheet" type="text/css" href="mystyle.css">
</head>
<body>
<header>
<h2 class="nineleaps">NineLeaps HR Portal</h2>
</header>
<ul id="header2">
<li><a href="#home">Home |</a></li>
<li id="table1">&nbspTable View</li>
</ul>
<h2 id="code3">ALL EMPLOYEES:</h2>
<table style="width:80%">
<tr>

    <th>E.ID</th>
    <th>Name</th> 
    <th>Designation</th>
     <th>Manager</th>
      <th>Date added</th>
      <th>View</th>
</tr>


<?php

while($row=mysqli_fetch_assoc($query))
{
    $timestamp=strtotime($row['date']);
    $date=date("j-F-Y",$timestamp);
    $name=$row['name'];
echo "<tr><td>".$row['eid']."</td><td>".$row['name']."</td><td>".$row['designation']."</td><td>".$row['manager']."</td><td>".$row['date']."</td><td><a href='emp_details.php?name=".$row['name']."&designation=".$row['designation']."&emp_id=".$row['eid']."&manager=".$row['manager']."'>view</a></td></tr>";
}
?>
</table>
  
<a href="add_details.php"><h4 id="code4">+Add More:</h4></a>
<a href="views.html"><h4 id="change">Change View</h4></a>
</body>
</html>

