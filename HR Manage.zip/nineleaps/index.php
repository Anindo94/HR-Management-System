<?php include 'code.php'; ?>
<html>
</head>

<title>NineLeaps Demo App</title>
<link rel="stylesheet" type="text/css" href="mystyle.css">
</head>
<body>
<header>
<h2 class="nineleaps">NineLeaps HR Portal</h2>
</header>
<div class="login">
	<div class="login1">
	<h2>Welcome!</h2>
	<h3>Please Enter Login Credentials</h3>
<form method="get">
Username:&nbsp<input type="text" name="userid" size="35">
<br><br>
Password:&nbsp&nbsp&nbsp<input type="password" name="psw" size="35">
<br><br>
 <input type="submit" name="login1" id="search" value="LOGIN">
</form>
</div>
<?php echo $error1;?>
</div>
</body>
</html>
